package main

type Datasource struct {
	Data []byte
}

type StatsData struct {
	Data []byte
}
